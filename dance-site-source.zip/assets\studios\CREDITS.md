# Studio Photo Credits

The photos are real dance-room photographs used as illustrative examples; they are not verified photos of the fictional studios listed on the page.

- `hall-sage.jpg`: "Sage empty dance studio" by minkymonkeymoo, Flickr, CC BY 2.0. Source: https://www.flickr.com/photos/45614557@N00/291828075
- `hall-mirror.jpg`: "Dance Studio" by mikecogh, Flickr, CC BY-SA 2.0. Source: https://www.flickr.com/photos/89165847@N00/6556818085
- `hall-cc0.jpg`: dance hall photo, Rawpixel, CC0 1.0. Source: https://www.rawpixel.com/image/5941524/free-public-domain-cc0-photo
- `dancer-studio.jpg`: "Dancer Rehearsing in a Studio" by Dancewear Central, Flickr, CC BY 2.0. Source: https://www.flickr.com/photos/98945402@N06/17237086510
- `ballet-warmup.jpg`: "Ballet Dancing Warm Up" by Dancewear Central, Flickr, CC BY 2.0. Source: https://www.flickr.com/photos/98945402@N06/17976154820
- `studio-bright.jpg`: "Dance Studio" by healthiermi, Flickr, CC BY-SA 2.0. Source: https://www.flickr.com/photos/54781600@N05/11240951836
- `studio-dance.jpg`: "Dance studio" by Rick McCharles, Flickr, CC BY 2.0. Source: https://www.flickr.com/photos/71035721@N00/4266776796

## Font

Manrope by Mikhail Sharanda, distributed under the SIL Open Font License 1.1. Source: https://fonts.google.com/specimen/Manrope
